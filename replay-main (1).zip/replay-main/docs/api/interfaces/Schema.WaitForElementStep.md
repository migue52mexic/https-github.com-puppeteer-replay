[@puppeteer/replay](../README.md) / [Schema](../modules/Schema.md) / WaitForElementStep

# Interface: WaitForElementStep

[Schema](../modules/Schema.md).WaitForElementStep

`waitForElement` allows waiting for the presence (or absence) of the number
of elements identified by the selector.

For example, the following step would wait for less than three elements
to be on the page that match the selector `.my-class`.

```
{
  "type": "waitForElement",
  "selectors": [".my-class"],
  "operator": "<=",
  "count": 2,
}
```

## Hierarchy

- [`StepWithSelectors`](Schema.StepWithSelectors.md)

  ↳ **`WaitForElementStep`**

## Table of contents

### Properties

- [assertedEvents](Schema.WaitForElementStep.md#assertedevents)
- [attributes](Schema.WaitForElementStep.md#attributes)
- [count](Schema.WaitForElementStep.md#count)
- [frame](Schema.WaitForElementStep.md#frame)
- [operator](Schema.WaitForElementStep.md#operator)
- [properties](Schema.WaitForElementStep.md#properties)
- [selectors](Schema.WaitForElementStep.md#selectors)
- [target](Schema.WaitForElementStep.md#target)
- [timeout](Schema.WaitForElementStep.md#timeout)
- [type](Schema.WaitForElementStep.md#type)
- [visible](Schema.WaitForElementStep.md#visible)

## Properties

### assertedEvents

• `Optional` **assertedEvents**: [`NavigationEvent`](Schema.NavigationEvent.md)[]

#### Inherited from

[StepWithSelectors](Schema.StepWithSelectors.md).[assertedEvents](Schema.StepWithSelectors.md#assertedevents)

#### Defined in

[Schema.ts:64](https://github.com/puppeteer/replay/blob/main/src/Schema.ts#L64)

---

### attributes

• `Optional` **attributes**: `Object`

Whether to also check the element(s) for the given attributes.

#### Index signature

▪ [name: `string`]: `string`

#### Defined in

[Schema.ts:273](https://github.com/puppeteer/replay/blob/main/src/Schema.ts#L273)

---

### count

• `Optional` **count**: `number`

**`Default Value`**

`1`

#### Defined in

[Schema.ts:256](https://github.com/puppeteer/replay/blob/main/src/Schema.ts#L256)

---

### frame

• `Optional` **frame**: [`FrameSelector`](../modules/Schema.md#frameselector)

Defaults to main frame

#### Inherited from

[StepWithSelectors](Schema.StepWithSelectors.md).[frame](Schema.StepWithSelectors.md#frame)

#### Defined in

[Schema.ts:78](https://github.com/puppeteer/replay/blob/main/src/Schema.ts#L78)

---

### operator

• `Optional` **operator**: `">="` \| `"=="` \| `"<="`

**`Default Value`**

`'=='`

#### Defined in

[Schema.ts:252](https://github.com/puppeteer/replay/blob/main/src/Schema.ts#L252)

---

### properties

• `Optional` **properties**: `Partial`\<`JSONSerializable`\<`HTMLElement`\>\> & \{ `[key: string]`: `JSONValue`; }

Whether to also check the element(s) for the given properties.

#### Defined in

[Schema.ts:267](https://github.com/puppeteer/replay/blob/main/src/Schema.ts#L267)

---

### selectors

• **selectors**: [`Selector`](../modules/Schema.md#selector)[]

A list of alternative selectors that lead to selection of a single element
to perform the step on. Currently, we support CSS selectors, ARIA selectors
(start with 'aria/'), XPath selectors (start with `xpath/`) and text
selectors (start with `text/`). Each selector could be a string or an array
of strings. If it's a string, it means that the selector points directly to
the target element. If it's an array, the last element is the selector for
the target element and the preceding selectors point to the ancestor
elements. If the parent element is a shadow root host, the subsequent
selector is evaluated only against the shadow DOM of the host (i.e.,
`parent.shadowRoot.querySelector`). If the parent element is not a shadow
root host, the subsequent selector is evaluated in the regular DOM (i.e.,
`parent.querySelector`).

During the execution, it's recommended that the implementation tries out
all of the alternative selectors to improve reliability of the replay as
some selectors might get outdated over time.

#### Inherited from

[StepWithSelectors](Schema.StepWithSelectors.md).[selectors](Schema.StepWithSelectors.md#selectors)

#### Defined in

[Schema.ts:100](https://github.com/puppeteer/replay/blob/main/src/Schema.ts#L100)

---

### target

• `Optional` **target**: `string`

Defaults to main

#### Inherited from

[StepWithSelectors](Schema.StepWithSelectors.md).[target](Schema.StepWithSelectors.md#target)

#### Defined in

[Schema.ts:71](https://github.com/puppeteer/replay/blob/main/src/Schema.ts#L71)

---

### timeout

• `Optional` **timeout**: `number`

#### Inherited from

[StepWithSelectors](Schema.StepWithSelectors.md).[timeout](Schema.StepWithSelectors.md#timeout)

#### Defined in

[Schema.ts:63](https://github.com/puppeteer/replay/blob/main/src/Schema.ts#L63)

---

### type

• **type**: [`WaitForElement`](../enums/Schema.StepType.md#waitforelement)

#### Overrides

[StepWithSelectors](Schema.StepWithSelectors.md).[type](Schema.StepWithSelectors.md#type)

#### Defined in

[Schema.ts:248](https://github.com/puppeteer/replay/blob/main/src/Schema.ts#L248)

---

### visible

• `Optional` **visible**: `boolean`

Whether to wait for elements matching this step to be hidden. This can be
thought of as an inversion of this step.

**`Default Value`**

`true`

#### Defined in

[Schema.ts:263](https://github.com/puppeteer/replay/blob/main/src/Schema.ts#L263)
